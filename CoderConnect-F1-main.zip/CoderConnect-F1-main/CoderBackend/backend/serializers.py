from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework import serializers
from django.contrib.auth import get_user_model

from backend.models import Post, ChatRoom, Comment, Message

User = get_user_model()


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["email"] = user.email
        return token

    def validate(self, attrs):
        credentials = {
            "username": attrs.get("email"),
            "password": attrs.get("password"),
        }
        user = User.objects.filter(email=credentials["username"]).first()

        if user and user.check_password(credentials["password"]):
            data = super().validate(attrs)
            data["email"] = user.email
            data["id"] = user.id
            data["username"] = user.username
            return data
        raise serializers.ValidationError("Invalid email or password")


class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["username", "email", "password"]

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data["username"],
            email=validated_data["email"],
            password=validated_data["password"],
            is_active=True,
        )
        return user


class PostSerializer(serializers.ModelSerializer):
    user_id = serializers.ReadOnlyField()
    username = serializers.ReadOnlyField()
    like_count = serializers.ReadOnlyField()
    comment_count = serializers.ReadOnlyField()

    class Meta:
        model = Post
        exclude = ["user"]

    def create(self, validated_data):
        # request = self.context.get('request')
        user = User.objects.first()
        post = Post.objects.create(user=user, **validated_data)
        ChatRoom.objects.create(post=post, name="Chat Room")
        return post
    

class CommentSerializer(serializers.ModelSerializer):
    user_name = serializers.ReadOnlyField()
    user_profile = serializers.ReadOnlyField()
    
    class Meta:
        model = Comment
        fields = "__all__"


class MessageSerializer(serializers.ModelSerializer):
    user_name = serializers.ReadOnlyField()
    class Meta:
        model = Message
        fields = "__all__"