from rest_framework.views import APIView
from rest_framework.decorators import action
from rest_framework import mixins, viewsets
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.views import TokenObtainPairView

from django.contrib.auth import get_user_model

from backend.serializers import CustomTokenObtainPairSerializer, RegisterSerializer, PostSerializer, MessageSerializer, CommentSerializer
from backend.models import Post, ChatRoom, Comment, Like, Message

User = get_user_model()

class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer

class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class PostViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.CreateModelMixin,
    viewsets.GenericViewSet
):

    queryset = Post.objects.all()
    serializer_class = PostSerializer
    # permission_classes = [IsAuthenticated] 
    # Uncomment above line when authentication implemented in UI

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


    @action(detail=True, methods=['post'])
    def like(self, request, pk=None):
        post = self.get_object()
        user = User.objects.first() # Hardcoded for now
        if Like.objects.filter(post=post, user=user).exists():
            return Response({"detail": "You already liked this post."}, status=status.HTTP_400_BAD_REQUEST)
        Like.objects.create(post=post, user=user)
        return Response({"detail": "Post liked."}, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'])
    def comment(self, request, pk=None):
        post = self.get_object()
        user = User.objects.first() # Hardcoded for now
        content = request.data.get('content')
        if not content:
            return Response({"detail": "Content is required."}, status=status.HTTP_400_BAD_REQUEST)
        Comment.objects.create(post=post, user=user, content=content)
        return Response({"detail": "Comment created."}, status=status.HTTP_201_CREATED)
    
    @action(detail=True, methods=['get'])
    def comments(self, request, pk=None):
        post = self.get_object()
        comments = post.comments.all()
        serializer = CommentSerializer(comments, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class ChatRoomViewSet(viewsets.GenericViewSet):
    queryset = ChatRoom.objects.all()
    serializer_class = MessageSerializer
    # permission_classes = [IsAuthenticated]

    @action(detail=True, methods=['post'])
    def create_message(self, request, pk=None):
        chatroom = self.get_object()
        user = User.objects.first() # Hardcoded for now
        content = request.data.get('content')
        if not content:
            return Response({"detail": "Content is required."}, status=status.HTTP_400_BAD_REQUEST)
        Message.objects.create(chatroom=chatroom, user=user, content=content)
        return Response({"detail": "Message created."}, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['get'])
    def messages(self, request, pk=None):
        chatroom = self.get_object()
        messages = chatroom.messages.all()
        serializer = MessageSerializer(messages, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
