from django.contrib import admin
from django.contrib.auth import admin as auth_admin
from django.contrib.auth import get_user_model
from backend.forms import UserChangeForm, UserCreationForm

from backend.models import Post, Like, Comment, ChatRoom, Message

User = get_user_model()


@admin.register(User)
class UserAdmin(auth_admin.UserAdmin):
    form = UserChangeForm
    add_form = UserCreationForm
    list_display = [
        "email",
        "first_name",
        "last_name",
        "is_active",
        "is_staff",
        "is_superuser",
    ]
    search_fields = ["email", "first_name"]
    ordering = ("first_name", "last_name")
    fieldsets = [
        (None, {"fields": ["email", "password"]}),
        ("Personal info", {"fields": ("first_name", "last_name")}),
        ("Permissions", {"fields": ["is_active", "is_staff", "is_superuser"]}),
        ("Important dates", {"fields": ("last_login", "date_joined")}),
    ]
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "password1", "password2"),
            },
        ),
    )
    # exclude = ("username",)


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ["title", "user", "created_at"]
    list_filter = ["created_at", "user"]
    search_fields = ["title", "content"]


@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    list_display = ["post", "user"]
    list_filter = ["post", "user"]
    search_fields = ["post__title", "user__email"]


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ["post", "user", "created_at"]
    list_filter = ["created_at", "user"]
    search_fields = ["content", "post__title", "user__email"]


@admin.register(ChatRoom)
class ChatRoomAdmin(admin.ModelAdmin):
    list_display = ["name", "post"]
    list_filter = ["post"]
    search_fields = ["name", "post__title"]


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ["chatroom", "user", "timestamp"]
    list_filter = ["timestamp", "user"]
    search_fields = ["content", "chatroom__name", "user__email"]
