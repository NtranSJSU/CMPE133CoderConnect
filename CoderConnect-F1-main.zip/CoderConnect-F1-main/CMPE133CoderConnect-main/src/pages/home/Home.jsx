import Posts from "../../components/posts/Posts"
import "./Home.scss"

const Home = () => {
  return (
    <div className="Home">
      <Posts/>
    </div>
  )
}

export default Home