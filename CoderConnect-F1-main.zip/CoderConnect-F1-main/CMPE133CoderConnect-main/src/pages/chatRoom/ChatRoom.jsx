import React, { useState, useEffect } from 'react';
import './ChatRoom.scss';
import axios from 'axios'; // Assuming you're using axios for API calls

const ChatRoom = () => {
    const [message, setMessage] = useState('');
    const [messages, setMessages] = useState([]);
    const [username, setUsername] = useState('User1'); 

    const fetchMessages = async () => {
        try {
            const response = await axios.get('http://127.0.0.1:8000/api/chatrooms/1/messages/');
            setMessages(response.data);
        } catch (error) {
            console.error('Error fetching messages:', error);
        }
    };
    useEffect(() => {
        fetchMessages();
    }, []);

    const handleSendMessage = async (event) => {
        event.preventDefault();
        if (message.trim()) {
            const newMessage = { content: message };

            try {
                await axios.post('http://127.0.0.1:8000//api/chatrooms/1/create_message/', newMessage);
            } catch (error) {
                console.error('Error sending message:', error);
            }
        }
        fetchMessages();
    };

    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            handleSendMessage(event); 
        }
    };

    return (
        <div className="chatroom">
            <h2>Chat Room</h2>
            <div className="chatbox">
                {messages?.map((msg, index) => (
                    <div key={index} className="message">
                        <strong>{msg.user_name}: </strong>{msg.content}
                    </div>
                ))}
            </div>
            <div className="input-container">
                <input 
                    type="text" 
                    value={message} 
                    onChange={(e) => setMessage(e.target.value)} 
                    placeholder="Type your message..." 
                    onClick={(e) => handleKeyPress()}
                    required 
                />
                <button type="submit" onClick={handleSendMessage}>Send</button>
            </div>
        </div>
    );
};

export default ChatRoom;
