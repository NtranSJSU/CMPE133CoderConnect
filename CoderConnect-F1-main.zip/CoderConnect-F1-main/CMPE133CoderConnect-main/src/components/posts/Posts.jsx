import { useState, useEffect } from "react";
import Post from "../post/Post";
import "./Posts.scss";

const Posts = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await fetch("http://127.0.0.1:8000/api/posts/");
        if (!response.ok) {
          throw new Error("Failed to fetch posts");
        }
        const data = await response.json();

        // Map API data to match the structure expected by Post.jsx
        const formattedPosts = data.map(post => ({
          id: post.id,
          name: post.username, 
          userId: post.user_id,
          desc: post.content,
          img: post.image,
          created: post.created_at,
          likes: post.like_count,
          commentCount: post.comment_count
        }));

        setPosts(formattedPosts);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="posts">
      {posts.map((post) => (
        <Post post={post} key={post.id} />
      ))}
    </div>
  );
};

export default Posts;