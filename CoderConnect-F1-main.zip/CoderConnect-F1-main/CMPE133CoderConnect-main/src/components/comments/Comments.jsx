import { useState, useEffect } from "react";
import "./comments.scss";
import userTemp from "../../assets/usertemp.jpg";
import { formatDistanceToNow } from "date-fns";

const Comments = ({ postID }) => {
  const [comments, setComments] = useState([]); // State for storing comments
  const [newComment, setNewComment] = useState(""); // State for new comment input
  const [loading, setLoading] = useState(false); // Loading state for API calls

  const currentUser = {
    profilePic: userTemp,
    name: "Current User",
  };

  // Fetch comments from the API
  const fetchComments = async () => {
    try {
      const response = await fetch(
        `http://127.0.0.1:8000/api/posts/${postID}/comments`
      ); // Replace with your API endpoint
      const data = await response.json();
      setComments(data);
    } catch (error) {
      console.error("Failed to fetch comments:", error);
    }
  };

  useEffect(() => {
    fetchComments();
  }, []);

  // Handle sending a new comment
  const handleSend = async () => {
    setLoading(true);

    try {
      const response = await fetch(
        `http://127.0.0.1:8000/api/posts/${postID}/comment/`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ content: newComment }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to send comment");
      }

      fetchComments();
    } catch (error) {
      console.error("Failed to send comment:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="comments">
      <div className="write">
        <img src={currentUser.profilePic} alt="" />
        <input
          type="text"
          placeholder="Write a comment"
          onChange={(e) => setNewComment(e.target.value)}
          disabled={loading}
        />
        <button onClick={handleSend} disabled={loading}>
          {loading ? "Sending..." : "Send"}
        </button>
      </div>
      {comments &&
        comments?.map((comment) => (
          <div className="comment" key={comment.id}>
            <img src={comment.user_profile} alt="" />
            <div className="info">
              <p>{comment.content}</p>
            </div>
            <span className="date">
              {formatDistanceToNow(new Date(comment.created_at))}
            </span>
          </div>
        ))}
    </div>
  );
};

export default Comments;
